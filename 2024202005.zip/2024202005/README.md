#LAB ACTIVITY 1
## TO RUN PROGRAM
- copy paste the below command
```shell
sh 2024202005_q1.sh
sh 2024202005_q2.sh
```
## Working
1. for question program is matching get post column(column number 6) with post and same with col 10 compare with 404.
2. for 2nd question program is summing the value row wise and printing it at the end.
